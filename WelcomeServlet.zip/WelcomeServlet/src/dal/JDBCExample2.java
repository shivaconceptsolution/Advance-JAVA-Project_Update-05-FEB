package dal;
import java.util.Scanner;
import java.sql.*;
public class JDBCExample2 {
   private int rno;
   private String sname;
   private String branch;
   private int fees;
   static Statement st;
   static Connection conn;
   public static void connect() throws ClassNotFoundException,SQLException
   {
	   Class.forName("com.mysql.jdbc.Driver");
	   conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/schooldb","root","");
	   st = conn.createStatement();
   }
   
   public static int insert(int rno,String sname,String branch, int fees) throws SQLException
   {
	   int res=st.executeUpdate("insert into tbl_student(rno,sname,branch,fees) values('"+rno+"','"+sname+"','"+branch+"','"+fees+"')");
       return res;
       
   
   }
   public static int userRegInsert(String uid,String upass,String email, String mobile) throws SQLException
   {
	   int res=st.executeUpdate("insert into tbl_reg(username,password,email,mobileno) values('"+uid+"','"+upass+"','"+email+"','"+mobile+"')");
       return res;
       
   
   }
   public static int FeedInsert(String fname,String fto, String rt) throws SQLException
   {
	   int res=st.executeUpdate("insert into tbl_feed(facultyname,feedto,rating) values('"+fname+"','"+fto+"','"+rt+"')");
       return res;
       
   
   }
   public static ResultSet userLogin(String uid,String pass) throws SQLException
   {	
	   ResultSet res = st.executeQuery("select * from tbl_reg where username='"+uid+"' and password='"+pass+"'");
	   return res;
   }
   
   public static int update(int rno,String sname,String branch, int fees) throws SQLException
   {
	   int res=st.executeUpdate("update tbl_student set sname='"+sname+"',branch='"+branch+"',fees='"+fees+"' where rno='"+rno+"'");
       return res;
   
   
   }
   
   
   public static int delete(int rno) throws SQLException
   {
	   int res=st.executeUpdate("delete from tbl_student where rno='"+rno+"'");
       return res;
   
   
   }
   
   public static 	ResultSet showdata() throws SQLException
   {	
	   ResultSet res = st.executeQuery("select * from tbl_student");
	   return res;
   }
   
   public static ResultSet login(String username,String pass) throws SQLException
   {	
	   ResultSet res = st.executeQuery("select * from tbl_admin where userid='"+username+"' and password='"+pass+"'");
	   return res;
   }
   
   public static ResultSet findData(int r) throws SQLException
   {
	   ResultSet res = st.executeQuery("select * from tbl_student where rno='"+r+"'");
	   return res;
   }
   public static void closeConn()  throws Exception
   {
	   conn.close();
   }
  
   
}
